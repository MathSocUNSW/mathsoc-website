function xdot=predprey_de(t,x)
a = 9; b = 1; c = 2; d = 1/5;
xdot=zeros(size(x));

xdot(1)=(a-b*x(2)).*x(1);
xdot(2)=(d*x(1)-c).*x(2);