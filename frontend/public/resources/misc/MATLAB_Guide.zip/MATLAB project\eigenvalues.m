function [solx, eig1, eig2] = eigenvalues(A)
    syms x
    a = 1; b = -(A(1,1) + A(2,2)); c = A(1,1)*A(2,2) - A(1,2)*A(2,1);
    eqn = a*x^2 + b*x + c == 0;
    solx = solve(eqn,x);

    [m, n]= size(A);
    A1 = A - solx(1,1)*eye(m); b1 = zeros(1,m)';
    A2 = A - solx(2,1)*eye(m); b2 = zeros(1,m)';
    eig1 = null(A1);
    eig2 = null(A2);
end