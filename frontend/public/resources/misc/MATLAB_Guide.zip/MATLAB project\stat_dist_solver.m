function[stat_dist] = stat_dist_solver(P)
  [m, n] = size(P);
  Q = P' - eye(m); %eye(n) creates a nxn identity matrix
  R = [Q(1:(m-1),:); ones(1,m)]; 
  V = [zeros(1,m-1),1]'; 
  stat_dist = R\V;
end