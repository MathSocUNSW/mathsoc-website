%% Calculate the orbits, flows and time plots of a predator-prey problem

global a b c d

% the parameters
a=9;
b=1;
c=2;
d=1/5;


%% stuff needed for the quiver plot
% the pred-prey equations are contained in the associated predprey_de.m
% file. With these parameters the steady state should be x=c/d, y=a/b
x0=linspace(0,2*c/d,20); % generate 10 points on the x-axis around the ss
y0=linspace(0,2*a/b,20); % generate 10 points on the y-axis around the ss

% now create a grid using these as the x and y coords
[X,Y]=meshgrid(x0,y0);

% calculate the derivatives at these points to be used in the quiver plot
U=(a-b*Y).*X; % the prey deriv
V=(d*X-c).*Y; % the predator deriv

%% stuff needed for the ODE plots
% now calculate the time solutions of the ODE to generate the orbits.
% Do this from 3 different starting points
xinit=[8 10 12; 2 2 2];

% solve each of these over the time interval
tspan=[0 10];

% save the output in a cell (so don't have to worry about every solution
% having the same number of points
xsol=cell(3,1);

for i=1:3
    [t,x]=ode45(@predprey_de,tspan, xinit(:,i));
    xsol(i)={[t,x]};
end
 
%% the plots
figure(1)
clf % clear the figure from any previous plot
% draw the arrows showing the velocity vector at the (X,Y) points
quiver(X,Y,U,V)
hold on % stop the previous plot from being deleted with the new plots
plot(c/d,a/b,'ro','MarkerFaceColor','r','MarkerSize',5)

% now plot the orbits from the ODE
for i=1:3
    sol=xsol{i}; % note the use of curly brackets here to extract the underlying matrix
    x=sol(:,2);
    y=sol(:,3);
    plot(x,y,'k-')
end

hold off
xlabel('Prey')
ylabel('Predators')
